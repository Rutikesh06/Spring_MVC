package com.wano.dao;

import java.util.List;

import com.wano.model.Student;

public interface StudentDao {

	void registerStudent(Student student);

	List<Student> getAllStudent();

	void updateStudent(Student student);

	List<Student> deleteStudent(int rollno);

	Student editStudent(int rollno);
}
