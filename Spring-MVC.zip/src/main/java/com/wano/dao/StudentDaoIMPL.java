package com.wano.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mysql.cj.x.protobuf.MysqlxConnection.Close;
import com.wano.model.Student;

@Repository
public class StudentDaoIMPL implements StudentDao {
	
	@Autowired
	private SessionFactory factory;

	public void registerStudent(Student student) {

		System.out.println("Dao Layer");

		Session session = factory.openSession();
		session.save(student);
		session.beginTransaction().commit();
		System.out.println("Data Save");
	}

	public List<Student> getAllStudent() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Student");
		List<Student> list = query.getResultList();
		session.close();
		return list;
	}


	public void updateStudent(Student student) {
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(student);
		tx.commit();
		
	}


	private List<Student> getAllStudentDetails() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Student");
		List<Student>list = query.getResultList();
		session.close();
		return list;
	}

	public List<Student> deleteStudent(int rollno) {
		Session session = factory.openSession();
		
		Student student = session.get(Student.class,rollno);
		Transaction tx = session.beginTransaction();
		session.delete(student);
		tx.commit();
		return getAllStudentDetails();
	}

	public Student editStudent(int rollno) {
	
		return factory.openSession().get(Student.class,rollno);
	}
}
