package com.wano.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.wano.model.Student;
import com.wano.service.StudentService;

@Controller
public class HomeController {

	@Autowired
	private StudentService service;

	public HomeController() {
		System.out.println("HomeController :: Cont");
	}

	@RequestMapping("/")
	public String landingPage() {

		System.out.println("landingPage :: call");
		return "index";
	}

	@RequestMapping("/logPage")
	public String loadingPage() {

		System.out.println("loadingPage :: call");

		return "login";
	}

	@RequestMapping("/log")
	public String loginCheck(@RequestParam String uname, @RequestParam String pass ,Model model) {
		System.out.println("LoginCheck :: call");

		if (uname.equals("admin") && pass.equals("admin@123")) {
			List<Student> stuList = service.getAllStudentDetails();
			System.out.println(stuList);
			model.addAttribute("data",stuList);
			return "success";
		} else
			return "login";
	}

	@RequestMapping("/regPage")
	public String registerPage()

	{
		System.out.println("registerpage ::  Called");
		return "register";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String registerStudent(@ModelAttribute Student student) {

		System.out.println("registerstudent :: called ");
		System.out.println(student);
		service.registerStudent(student);

		return "login";
	}
	
	@RequestMapping("/up")
	public String updateStudent(@ModelAttribute Student student)
	{
		service.updateStudent(student);
	return "login";
	}

	@RequestMapping("/delete")
	public String deleteStudent(@RequestParam int rollno,Model model)
	{
	System.out.println("We are Deleting Student "+rollno);
	List<Student> stuList = service.deleteStudent(rollno);
	model.addAttribute("data",stuList);
		return"success";
	}
	@RequestMapping("/edit")
	public String editStudent(@RequestParam int rollno,Model model) {
		System.out.println("Edit Call");
		Student stu = service.editStudent(rollno);
		System.out.println(stu);
		model.addAttribute("student",stu);
		return"update";
	}
}
