package com.wano.service;

import java.util.List;

import com.wano.model.Student;

public interface StudentService {
	void registerStudent(Student student);

	List<Student> getAllStudentDetails();

	void updateStudent(Student student);

	List<Student> deleteStudent(int rollno);

	Student editStudent(int rollno);

	
}
