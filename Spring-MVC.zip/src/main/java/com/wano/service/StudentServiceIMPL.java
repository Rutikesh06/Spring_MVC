package com.wano.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wano.dao.StudentDao;
import com.wano.model.Student;

@Service
public class StudentServiceIMPL implements StudentService {
	@Autowired
	private StudentDao dao;
	
	
	
	public void registerStudent(Student student) {
		System.out.println("register ");
	
		dao.registerStudent(student);
	}



	public List<Student> getAllStudentDetails() {
	
		return dao.getAllStudent();
	}



	public void updateStudent(Student student) {
		
		
		 dao.updateStudent(student);
		
	}



	public List<Student> deleteStudent(int rollno) {
		
		return dao.deleteStudent(rollno);
	}



	public Student editStudent(int rollno) {
		
		return dao.editStudent(rollno);
	}
}
